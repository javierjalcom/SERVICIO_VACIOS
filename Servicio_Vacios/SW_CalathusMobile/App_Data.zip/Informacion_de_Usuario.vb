﻿Public Class Informacion_de_Usuario
    Public s_username As String
    Public i_unsername_id As Integer
End Class
